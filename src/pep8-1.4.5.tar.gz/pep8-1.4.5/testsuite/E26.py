#: E261
pass # an inline comment
#: E262
x = x + 1  #Increment x
#: E262
x = x + 1  #  Increment x
#: E262
x = y + 1  #:  Increment x
#: Okay
pass  # an inline comment
x = x + 1   # Increment x
y = y + 1   #: Increment x
#:
